from django.db import models

# Create your models here.
class Customers(models.Model):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    email = models.EmailField()
    phone_number = models.IntegerField(null=True)
    arrival_date =  models.DateField()   
    number_of_days =  models.IntegerField(default=1)
    number_of_rooms = models.IntegerField(default=1)
    number_of_adults = models.IntegerField(default=1)
    number_of_kids = models.IntegerField(default=0)
    bed_type = models.CharField(max_length = 1)
    pay = models.FloatField(default=0)
    
    
    def __str__(self):
        return self.first_name

'''class Employee(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length = 255)
    password = models.CharField(max_length = 255)
    email = models.EmailField()
    #phone_number=models.IntegerField()
    
    def __str__(self):
        return self.first_name'''
    