
from django.contrib import admin
from django.urls import path
from accomodation import views

urlpatterns = [
    
    path('newhotel/',views.newhotel, name='newhotel' ),
    path('newhotel/about/', views.about, name='about'),
    path('newhotel/location/', views.location, name='location'),
    path('newhotel/pictures/', views.pictures, name='pictures'),
    path('newhotel/booking/', views.booking, name='booking'),
    path('newhotel/transport/', views.transport, name='transport'),
    path('newhotel/login', views.login, name='login'),
    path('newhotel/logout', views.logout, name='logout'),
    path('newhotel/register_employee', views.register_employee, name='register_employee'),
    path('newhotel/register_employee_2', views.register_employee_2, name='register_employee_2'),
    path('newhotel/booked_customers', views.booked_customers, name='booked_customers'),
    path('newhotel/booking', views.booking, name='booking'),
    path('newhotel/booking/booking', views.submit_reservation, name='submit_reservation' ),
    path('confirm/', views.confirm, name='confirm'),
    path('newhotel/check_customer', views.check_customer, name='check_customer'),
    path('newhotel/customer', views.show_customer_data, name='show_customer_data'),
]
