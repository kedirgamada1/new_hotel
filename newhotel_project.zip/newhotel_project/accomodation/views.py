from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from accomodation.models import Customers
from django.contrib import messages
from django.contrib.auth.models import User, auth

# Create your views here.
kings=59.99
queens=49.99
tweens=39.99

class Password_validator:
    def __init__(self, password):
        self.password = password
        
    def char_length(self):
        if len(self.password) < 8:
            return 'The length of password can not be less than 8'

def newhotel(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def location(request):
    return render(request, 'location.html')

def pictures(request):
    return render(request, 'pictures.html')

def booking(request):
    return render(request, 'booking.html')

def transport(request):
    return render(request, 'transport.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            
            messages.info(request, f'Now you are loggedin as {user} ' )
 
            return render(request, 'employee_page.html')
        else:
            messages.error(request, 'Invalid credentials')
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')

def logout(request):
    auth.logout(request)
    return redirect('newhotel')

def register_employee(request):
    return render(request, 'employee_registration_form.html')

# New employee registration
def register_employee_2(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        password2 = str(password2)
        email = request.POST['email']
        #validating password                             
        if len(password) >= 8:
            if not any(char.isupper() for char in password):
                messages.info(request, 'at lease one upercase letter needed')
                return render(request, 'employee_registration_form.html')
                
            elif not any(char.islower() for char in password):
                messages.info(request, 'at lease one lowercase letter needed')
                return render(request, 'employee_registration_form.html')
                
            elif not any(char.isdigit() for char in password):
                messages.info(request, 'Password must contain at least one digit')
                return render(request, 'employee_registration_form.html')
            elif not any(char in "!@#$%^&*()-_=+[]{}|;:'\",.<>?/" for char in password):
                messages.info(request, 'at lease one special letter needed')
                return render(request, 'employee_registration_form.html')
            else:
                
                if  password == password2:
                    if User.objects.filter(username=username).exists():   
                        messages.info(request, 'Username taken')
                        return render(request, 'employee_registration_form.html')
                            
                    elif User.objects.filter(email=email).exists():
                        messages.add_message(request, messages.INFO, "email taken. Please use another email")
                        return render(request, 'employee_registration_form.html')
                
                    else:   
                        user = User.objects.create_user(first_name=first_name, last_name=last_name, username=username, password=password, email=email)
                        user.save();
                        messages.add_message(request, messages.INFO, f"{first_name} is added to the database. Now {first_name} can login.")
                        return render(request, 'login.html')
                                
                else:
                    messages.info(request, 'password does not much')
                    return render(request, 'employee_registration_form.html')
        else:
            messages.info(request, 'Password can not be less than 8 character')
            return render(request, 'employee_registration_form.html')

    else:
        return render(request, 'employee_registration_form.html')

    
        
            
# To check if a customer has been booked online
def check_customer(request):
    #Customers.objects.filter(email=)
    return render(request, 'check_customer.html') 
def show_customer_data(request):
    if request.method=='POST':
        last_name = request.POST['lname']
        if Customers.objects.filter(last_name=last_name).exists():
            customer = Customers.objects.filter(last_name=last_name).values()
            return render(request, 'customer_available.html', {'customer':customer})
        else:
            return render(request, 'not_booked.html', {'last_name':last_name})
    else:
        return render(request, 'check_customer.html')      
     
def booked_customers(request):
    customers = Customers.objects.all()
    return render(request, 'booked_customers.html', {'customers':customers})
def booking(request):
    bed_type = {}
    return render(request, 'booking.html')

def submit_reservation(request):
    # Get the input from the user
    if request.method=='POST':
        firstname=request.POST['first_name']
        lastname=request.POST['last_name']
        email=request.POST['email']
        phone=request.POST['phone']
        arrival=request.POST['arrival_date']
        number_of_staying_days=int(request.POST['num_of_days'])
        rooms=int(request.POST['rooms'])
        adults=request.POST['adult']
        kids=request.POST['kids']
        bed_type = request.POST['beds']
        # Calculate cost of staying depending on type of bed and assign bed type
        if bed_type == '1':
            bed = 'King'
            cost = kings * number_of_staying_days * rooms
        elif bed_type == '2':
            bed = 'Queen'
            cost = queens * number_of_staying_days * rooms
        elif bed_type == '3':
            bed = 'tweens'
            cost = tweens * number_of_staying_days * rooms
            cost = format(cost, ".2f")  
        bed = bed
        cost = cost
        # Save the data to the database
        booking = Customers(first_name=firstname, last_name=lastname, email=email,phone_number=phone, arrival_date=arrival, number_of_days=number_of_staying_days, number_of_rooms=rooms, number_of_adults=adults,number_of_kids=kids, bed_type=bed_type)
        booking.save()
        # Show the summary of the booking to the user
        customer = {'firstname':firstname,
                    'lastname':lastname, 
                   'email':email,
                   'phone':phone,
                   'arrival':arrival,
                   'number_of_staying_days':number_of_staying_days,
                   'rooms':rooms,
                   
                   'adults':adults,
                   'kids':kids,
                   'cost':cost,
                   'bed':bed,
                   
                  
                  }
        return render(request, 'booked.html', {'customer':customer})
    
def confirm(request):
    if request.method=='POST':
        firstname=request.POST['first_name']
        lastname=request.POST['last_name']
        email=request.POST['email']
        phone=request.POST['phone']
        arrival=request.POST['arrival_date']
        num_of_days=request.POST['num_of_days']
        rooms=request.POST['rooms']
        
        adults=request.POST['adult']
        kids=request.POST['kids']
        
        
        
        #customers = Customers(first_name=firstname, last_name=lastname, email=email,phone=phone, arrival_date=arrival, num_of_days=num_of_days, number_of_rooms=rooms, number_of_adults=adults,number_of_kids=kids )
        #customers.save();
        

    return render(request, 'confirmed.html')    


'''class User:
    def __init__(self, username, password, email):
        self.username = username
        self.password = password
        self.email = email



    def check_username(self):
        if self.username in username:
            print(f'username {self.username} found in the username list')
        else:
            pass #print(f"username {self.username} is not in the list")
    def password_length(self):
        if len(self.password) <8:
            print("The length of the password can not be less than 8 character")
        else:
            pass #print("The length of the password is good")
    def number_in_password(self):
        num = [1234567890]
        num = str(num)
        for char in self.password:
            if char not in num:
                print(f"Your password needs to have a number in it.")
            else:
                print(f"your password has a number {char}")
    def check_password(self):
        char_list = "!@#$%^&*()-_=+[]{}|;:'\",.<>?/"
        char_list = str(char_list)
        for char in self.password:
            if char not in char_list:
                print(f'at least one  of the special character from "{char_list}" needs to be there')
            else:
                pass #print("your password is good")
    def check_email(self):
        at = "@"
        for char in self.email:
            if at not in self.email:
                print(f"Please put valid email.")
            else:
                pass #print("your email is also valid")'''
